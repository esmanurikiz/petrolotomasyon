﻿using System;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace Petrol
{
    public partial class FrmGiris : Form
    {
        private DataBaseHelper dbHelper; 

        public FrmGiris()
        {
            InitializeComponent();
            dbHelper = new DataBaseHelper();
        }
        private void button1_Click(object sender, EventArgs e)
        {
            string kullaniciAd = txtAd.Text;
            string sifre = txtSifre.Text;

            using (SqlConnection connection = dbHelper.GetConnection())
            {
                try
                {
                    string query = "SELECT ad, soyad, yetki, sube FROM Kullanici WHERE kullanici_ad = @kullaniciAd AND sifre = @sifre";
                    SqlCommand command = new SqlCommand(query, connection);
                    command.Parameters.AddWithValue("@kullaniciAd", kullaniciAd);
                    command.Parameters.AddWithValue("@sifre", sifre);

                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            string ad = reader["ad"].ToString();
                            string soyad = reader["soyad"].ToString();
                            string yetki = reader["yetki"].ToString();
                            string sube = reader["sube"].ToString();
                            switch (yetki)
                            {
                                case "Yönetici":
                                    FrmYonetici form2 = new FrmYonetici();
                                    form2.Show();
                                    this.Hide();
                                    break;
                                case "Şube Müdürü":
                                    FrmSubeMüdürü form3 = new FrmSubeMüdürü(ad, soyad,sube);
                                    form3.Show();
                                    this.Hide();
                                    break;
                                case "Pompacı":
                                    FrmPompaci form4 = new FrmPompaci(ad, soyad,sube);
                                    form4.Show();
                                    this.Hide();
                                    break;
                                default:
                                    MessageBox.Show("Yetki tanımlı değil!");
                                    break;
                            }
                        }
                        else
                        {
                            MessageBox.Show("Kullanıcı adı veya şifre hatalı!");
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Bir hata oluştu: " + ex.Message);
                }
            }
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }


}
